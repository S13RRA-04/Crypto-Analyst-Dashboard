import { Component } from '@angular/core';

@Component({
  selector: 'app-dune-tool',
  imports: [],
  standalone: true,
  templateUrl: './dune-tool.component.html',
  styleUrl: './dune-tool.component.scss'
})
export class DuneToolComponent {

}
