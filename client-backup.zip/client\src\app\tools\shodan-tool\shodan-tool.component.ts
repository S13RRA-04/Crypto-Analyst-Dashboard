import { Component } from '@angular/core';

@Component({
  selector: 'app-shodan-tool',
  imports: [],
  standalone: true,
  templateUrl: './shodan-tool.component.html',
  styleUrl: './shodan-tool.component.scss'
})
export class ShodanToolComponent {

}
