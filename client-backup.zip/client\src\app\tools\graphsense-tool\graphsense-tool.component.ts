import { Component } from '@angular/core';

@Component({
  selector: 'app-graphsense-tool',
  imports: [],
  standalone: true,
  templateUrl: './graphsense-tool.component.html',
  styleUrl: './graphsense-tool.component.scss'
})
export class GraphsenseToolComponent {

}
