import { Component } from '@angular/core';

@Component({
  selector: 'app-investigation-logs',
  imports: [],
  standalone: true,
  templateUrl: './investigation-logs.component.html',
  styleUrl: './investigation-logs.component.scss'
})
export class InvestigationLogsComponent {

}
